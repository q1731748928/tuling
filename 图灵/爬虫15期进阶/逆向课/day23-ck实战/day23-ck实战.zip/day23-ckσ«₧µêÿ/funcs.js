

content = "arg2"

function gets() {
    return "hello" + content
}